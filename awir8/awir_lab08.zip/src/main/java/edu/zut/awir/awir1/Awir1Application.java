package edu.zut.awir.awir1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Awir1Application {

	public static void main(String[] args) {

		SpringApplication.run(Awir1Application.class, args);
	}

}
